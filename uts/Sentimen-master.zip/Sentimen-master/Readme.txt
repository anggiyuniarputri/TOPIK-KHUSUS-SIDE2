Anggota : 
Anggi Yuniar Putri (1301154492)
Fakry Adi Permana  (1301164034)

How to run code :
- run java server first (need to install coreNLP first)
- run program
